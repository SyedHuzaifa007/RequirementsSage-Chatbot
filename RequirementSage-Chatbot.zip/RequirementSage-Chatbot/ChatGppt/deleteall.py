# import os
# # os.environ.setdefault("DJANGO_SETTINGS_MODULE", "settings")
# from django.db import connection


# from xhatapp.models import SaveQueries

# def clean_data():
#     SaveQueries.objects.all().delete()
#     print("deleted all.... ")

# clean_data()