from django.contrib import admin
from xhatapp.models import SaveQueries,UserInfo
# Register your models here.

admin.site.register(SaveQueries)
admin.site.register(UserInfo)